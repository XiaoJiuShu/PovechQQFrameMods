package mod.a.example;

import com.povech.api.model.message.Message;
import com.povech.api.plugin.PluginContext;
import com.povech.api.service.message.MessageService;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.Objects;

/**
 * 插件设置界面示例，对应 PluginInitializer.createSettingsFrame()。
 *
 * 这个方法是 PluginInitializer 上的 default 方法，默认实现直接返回 null，
 * 也就是"本插件没有设置界面"。想要设置界面就在 Initializer 里覆盖它，返回一个 JFrame。
 *
 * 三点框架行为无法从 SDK 字节码确认（SDK 只有接口，实现在框架源码里），
 * 下面的写法按最保守的假设处理，如果实际表现不一致，照注释调整即可：
 *
 * 1. 框架从哪个线程调用 createSettingsFrame()。Swing 组件必须在事件分发线程（EDT）上创建，
 *    这里假设框架是在用户点"设置"时于 EDT 上调用的。若发现不是，把 buildFrame() 的内容
 *    包进 SwingUtilities.invokeAndWait(...) 即可（注意已在 EDT 上时调用 invokeAndWait 会死锁，
 *    需要先用 SwingUtilities.isEventDispatchThread() 判断）。
 * 2. 框架是否自己调用 setVisible(true)。这里只返回配置好的窗口、不自己显示，
 *    这是返回 JFrame 这种签名的惯常约定。若打开设置没反应，就在返回前加 frame.setVisible(true)。
 * 3. 框架是否每次打开设置都重新调用本方法。这里缓存同一个实例并用 HIDE_ON_CLOSE，
 *    这样反复打开都能正常显示；如果用 DISPOSE_ON_CLOSE，关掉再打开会拿到已销毁的窗口。
 *
 * 设置项这里只存在内存里。SDK 没有暴露插件配置目录，需要持久化得自己选路径写文件。
 */
public class SettingsExample {
    private final PluginContext context;
    private final MessageService messageService;

    /** 缓存窗口实例，避免每次打开设置都新建一个 */
    private JFrame frame;

    // ---- 设置项，仅存在内存中 ----
    private long targetGroupId;
    private boolean autoApproveFriendRequest;

    public SettingsExample(PluginContext context) {
        this.context = Objects.requireNonNull(context, "context");
        this.messageService = context.messages();
    }

    /**
     * 供 Initializer.createSettingsFrame() 调用。
     */
    public JFrame getOrCreateFrame() {
        if (frame == null) {
            frame = buildFrame();
        }
        return frame;
    }

    private JFrame buildFrame() {
        JFrame settings = new JFrame("示例插件设置");
        // HIDE_ON_CLOSE：关闭只隐藏，窗口实例还能复用。
        // 不要用 EXIT_ON_CLOSE，那会把整个框架进程一起关掉。
        settings.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        JTextField groupIdField = new JTextField(targetGroupId == 0 ? "" : String.valueOf(targetGroupId));
        JCheckBox autoApproveBox = new JCheckBox("自动同意好友请求", autoApproveFriendRequest);
        JLabel status = new JLabel("就绪");

        JPanel form = new JPanel(new GridLayout(2, 2, 8, 8));
        form.add(new JLabel("目标群号："));
        form.add(groupIdField);
        form.add(new JLabel("好友请求："));
        form.add(autoApproveBox);

        JButton save = new JButton("保存");
        JButton sendTest = new JButton("发送测试消息");

        // ActionListener 在 EDT 上执行，读写组件是安全的
        save.addActionListener(e -> {
            Long parsed = parseGroupId(groupIdField.getText());
            if (parsed == null) {
                status.setText("群号必须是数字");
                return;
            }
            targetGroupId = parsed;
            autoApproveFriendRequest = autoApproveBox.isSelected();
            context.logger().info("设置已保存：群号=" + targetGroupId
                    + " 自动同意好友请求=" + autoApproveFriendRequest);
            status.setText("已保存");
        });

        sendTest.addActionListener(e -> {
            Long parsed = parseGroupId(groupIdField.getText());
            if (parsed == null || parsed == 0) {
                status.setText("请先填写有效群号");
                return;
            }
            status.setText("发送中");
            messageService.sendGroupMessage(parsed, Message.text("来自设置界面的测试消息"))
                    .thenAccept(result ->
                            // 关键：thenAccept 的回调不在 EDT 上，改动 Swing 组件
                            // 必须切回 EDT，否则会出现界面不刷新或错乱
                            SwingUtilities.invokeLater(() ->
                                    status.setText("已发送 messageId=" + result.messageId())))
                    .exceptionally(error -> {
                        SwingUtilities.invokeLater(() -> status.setText("发送失败：" + error.getMessage()));
                        return null;
                    });
        });

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(save);
        buttons.add(sendTest);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        content.add(form);
        content.add(Box.createVerticalStrut(8));
        content.add(buttons);

        settings.setLayout(new BorderLayout());
        settings.add(content, BorderLayout.CENTER);
        settings.add(status, BorderLayout.SOUTH);
        settings.setMinimumSize(new Dimension(360, 200));
        settings.pack();
        settings.setLocationRelativeTo(null);
        return settings;
    }

    /**
     * 群号来自用户手输，必须校验。返回 null 表示输入非法。
     */
    private Long parseGroupId(String raw) {
        String trimmed = raw == null ? "" : raw.trim();
        if (trimmed.isEmpty()) {
            return 0L;
        }
        try {
            long value = Long.parseLong(trimmed);
            return value < 0 ? null : value;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    // ---- 供其他示例读取设置值 ----

    public long targetGroupId() {
        return targetGroupId;
    }

    /**
     * MiscExample 里自动同意好友请求的开关默认是关的。想让设置界面真正接管它，
     * 把本实例传进 MiscExample，在 onFriendRequest 里读这个值再决定是否调用
     * approveFriendRequest。
     */
    public boolean autoApproveFriendRequest() {
        return autoApproveFriendRequest;
    }

    /**
     * 插件卸载时释放窗口资源。Initializer.onDisable() 里应当调用。
     */
    public void dispose() {
        if (frame != null) {
            frame.dispose();
            frame = null;
        }
    }
}
